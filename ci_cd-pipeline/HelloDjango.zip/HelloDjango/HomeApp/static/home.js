function fun_button_testButton() {
    alert("A hello from Django on Feb-27th, 2023...");
}